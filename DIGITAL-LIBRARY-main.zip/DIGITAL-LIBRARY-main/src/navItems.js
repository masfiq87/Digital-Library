export const items = [
  {
    id: 1,
    title: "Books",
    url: "#",
    cName: "nav-links",
  },
  {
    id: 2,
    title: "About",
    url: "#",
    cName: "nav-links",
  },
];
