export const categoryItem = [
  {
    id: 1,
    class: "link link1",
    mainHandler: "category-item",
    spanImg:
      "https://sc02.alicdn.com/kf/HTB12RuNUmzqK1RjSZFH7623CpXa6.png_50x50xz.jpg",
    txt: "Department",
    prefixed_icon: ">",
  },
];
