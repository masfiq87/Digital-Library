export const sliderInfo = [
  {
    id: 1,
    cName: "slide ",
    img: "./rsz_1.png",
    h3: "Getting Books Made Easy",
    p: "Get your favourite book with just a click of a button",
  },
  {
    id: 2,
    cName: "slide ",
    img: "./rsz_differentbooks.png",
    h3: "Book Of Different Kinds",
    p: "We Have Every Book That You Can Think Of",
  },
  {
    id: 3,
    cName: "slide ",
    img: "./rsz_1personreading.png",
    h3: "Easy Accessable learning experience",
    p: "Download pdf or complete book",
  },
  {
    id: 4,
    cName: "slide ",
    img: "./rsz_2py.png",
    h3: "Learn New Technologies",
    p: "Get along with the current hot topics",
  },
];
