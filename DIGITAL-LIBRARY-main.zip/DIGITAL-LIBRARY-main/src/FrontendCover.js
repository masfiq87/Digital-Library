// import React from "react";
// import Button from "@mui/material/Button";
// import { Link } from "react-router-dom";

// function FrontendCover() {
//   return (
//     <>
//       <div className="frontend-cover">
//         <div className="information">
//           <h1>THE BEST BOOKS AND MAGAZINES ARE WAITING FOR YOU</h1>
//           <Button variant="contained">Subscribe</Button>
//         </div>
//         <div className="information-img"></div>
//       </div>
//     </>
//   );
// }

// export default FrontendCover;
